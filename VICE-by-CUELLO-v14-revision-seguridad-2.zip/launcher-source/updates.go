package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

var repositoryIDs = [6]string{"Marvisak/VIctory", "fxceless/victory-fork", "Zettrox/ztrx", "xcl-dev/xcl", "Belobug/VIctory-Belobug-AMD", "uiliannn/VItoriaBr"}
var shaPattern = regexp.MustCompile(`^[a-f0-9]{40}$`)

type portVersion struct {
	Path, InstalledSHA, SeenSHA, LatestSHA string
	Available                              bool
}
type updateSettings struct {
	Disabled  bool
	Ports     [6]portVersion
	LastCheck time.Time
}
type remoteVersion struct {
	SHA string `json:"sha"`
}
type updateResult struct {
	Versions [6]string
	Errors   [6]string
	Manual   bool
}

func getLatest(client *http.Client, base, repo string) (string, error) {
	req, err := http.NewRequest("GET", base+"/repos/"+repo+"/commits?per_page=1", nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("User-Agent", "VICE-Launcher/11.0")
	req.Header.Set("X-GitHub-Api-Version", "2022-11-28")
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("GitHub HTTP %d", resp.StatusCode)
	}
	var v []remoteVersion
	if err = json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&v); err != nil {
		return "", err
	}
	if len(v) == 0 || !shaPattern.MatchString(v[0].SHA) {
		return "", fmt.Errorf("Respuesta sin revision valida")
	}
	return v[0].SHA, nil
}
func observeVersion(p portVersion, path, latest string) (portVersion, bool) {
	if p.Path != path {
		p = portVersion{Path: path}
	}
	if !shaPattern.MatchString(latest) {
		return p, false
	}
	previous := p.SeenSHA
	p.LatestSHA = latest
	// Imported builds have no trustworthy commit provenance; first check establishes upstream baseline only.
	if p.InstalledSHA != "" {
		p.Available = p.InstalledSHA != latest
	} else if previous != "" && previous != latest {
		p.Available = true
	}
	p.SeenSHA = latest
	return p, p.Available && (previous != latest)
}
func readUpdates(dir string) updateSettings {
	var v updateSettings
	b, e := os.ReadFile(filepath.Join(dir, "updates-v10.json"))
	if e == nil {
		_ = json.Unmarshal(b, &v)
	}
	return v
}
func writeUpdates(dir string, v updateSettings) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(filepath.Join(dir, "updates-v10.json"), b, 0600)
}
func shortSHA(s string) string {
	if len(s) >= 8 {
		return s[:8]
	}
	return s
}
func primaryState(motor, game, busy bool, name string) string {
	if busy {
		return "Tarea en curso"
	}
	if !motor {
		return "Instalar " + name
	}
	if !game {
		return "Vincular juego"
	}
	return "Jugar con " + name
}
func repoURL(i int) string   { return "https://github.com/" + repositoryIDs[i] }
func validSHA(s string) bool { return shaPattern.MatchString(strings.TrimSpace(s)) }

// GitHub metadata must not be redirected to arbitrary external hosts.
func checkMetadataRedirect(req *http.Request, via []*http.Request) error {
	if len(via) >= 5 || !allowedMetadataURL(req.URL) {
		return fmt.Errorf("Redireccion de metadatos no autorizada")
	}
	return nil
}
func allowedMetadataURL(u *url.URL) bool {
	return u != nil && u.Scheme == "https" && u.User == nil && u.Port() == "" && strings.EqualFold(u.Hostname(), "api.github.com")
}
