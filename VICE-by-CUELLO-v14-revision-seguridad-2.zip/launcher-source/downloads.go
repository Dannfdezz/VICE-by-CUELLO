package main

import (
	"archive/zip"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"
)

// Download source only. No code is executed until a separate local compilation confirmation.
func downloadSource(repo, sha, parent string) (string, error) {
	if !shaPattern.MatchString(sha) || !knownRepository(repo) {
		return "", fmt.Errorf("Revision no valida")
	}
	if e := os.MkdirAll(parent, 0755); e != nil {
		return "", e
	}
	dest, e := os.MkdirTemp(parent, "source-"+sha[:8]+"-")
	if e != nil {
		return "", e
	}
	client := &http.Client{Timeout: 3 * time.Minute, CheckRedirect: checkSourceRedirect}
	req, e := http.NewRequest("GET", "https://codeload.github.com/"+repo+"/zip/"+sha, nil)
	if e != nil {
		return "", e
	}
	req.Header.Set("User-Agent", "VICE-Launcher/11.0")
	resp, e := client.Do(req)
	if e != nil {
		return "", e
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("Descarga HTTP %d", resp.StatusCode)
	}
	archive := filepath.Join(dest, "source.zip")
	f, e := os.OpenFile(archive, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return "", e
	}
	n, e := io.Copy(f, io.LimitReader(resp.Body, 128<<20+1))
	ce := f.Close()
	if e != nil {
		return "", e
	}
	if ce != nil {
		return "", ce
	}
	if n > 128<<20 {
		return "", fmt.Errorf("ZIP demasiado grande")
	}
	zr, e := zip.OpenReader(archive)
	if e != nil {
		return "", e
	}
	defer zr.Close()
	return extractSource(&zr.Reader, filepath.Join(dest, "src"))
}
func extractSource(zr *zip.Reader, dest string) (string, error) {
	if len(zr.File) > 30000 {
		return "", fmt.Errorf("Demasiados archivos")
	}
	if e := os.MkdirAll(dest, 0755); e != nil {
		return "", e
	}
	var total uint64
	top := ""
	for _, z := range zr.File {
		name := strings.TrimSuffix(z.Name, "/")
		parts := strings.Split(name, "/")
		if name == "" || strings.ContainsAny(name, "\\:\x00") || path.Clean(name) != name || strings.HasPrefix(name, "/") {
			return "", fmt.Errorf("Ruta ZIP no segura")
		}
		for _, p := range parts {
			if !safeArchiveComponent(p) {
				return "", fmt.Errorf("Ruta ZIP no segura")
			}
		}
		if top == "" {
			top = parts[0]
		}
		if parts[0] != top {
			return "", fmt.Errorf("ZIP con varias raices")
		}
		if z.Mode()&os.ModeSymlink != 0 || (!z.FileInfo().IsDir() && !z.Mode().IsRegular()) {
			return "", fmt.Errorf("Tipo de archivo no permitido")
		}
		out := filepath.Join(dest, filepath.FromSlash(name))
		if z.FileInfo().IsDir() {
			if e := os.MkdirAll(out, 0755); e != nil {
				return "", e
			}
			continue
		}
		if z.UncompressedSize64 > 128<<20 || total+z.UncompressedSize64 > 512<<20 {
			return "", fmt.Errorf("ZIP excede limite de extraccion")
		}
		total += z.UncompressedSize64
		if e := os.MkdirAll(filepath.Dir(out), 0755); e != nil {
			return "", e
		}
		r, e := z.Open()
		if e != nil {
			return "", e
		}
		w, e := os.OpenFile(out, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if e != nil {
			r.Close()
			return "", e
		}
		n, e := io.Copy(w, io.LimitReader(r, int64(z.UncompressedSize64)+1))
		r.Close()
		ce := w.Close()
		if e != nil {
			return "", e
		}
		if ce != nil {
			return "", ce
		}
		if uint64(n) != z.UncompressedSize64 {
			return "", fmt.Errorf("Tamano ZIP incorrecto")
		}
	}
	dir := filepath.Join(dest, top)
	if _, e := os.Stat(filepath.Join(dir, "Cargo.toml")); e != nil {
		return "", fmt.Errorf("No hay Cargo.toml en el repositorio")
	}
	return dir, nil
}

// Restrict downloads to the advertised repositories and exact revisions.
func knownRepository(repo string) bool {
	for _, allowed := range repositoryIDs {
		if repo == allowed {
			return true
		}
	}
	return false
}
func allowedSourceURL(u *url.URL) bool {
	return u != nil && u.Scheme == "https" && u.User == nil && u.Port() == "" && strings.EqualFold(u.Hostname(), "codeload.github.com")
}
func checkSourceRedirect(req *http.Request, via []*http.Request) error {
	if len(via) >= 5 || !allowedSourceURL(req.URL) {
		return fmt.Errorf("Redireccion de descarga no autorizada")
	}
	return nil
}

// Apply Windows naming rules even when these tests run on another OS.
func safeArchiveComponent(p string) bool {
	if p == "" || p == "." || p == ".." || strings.TrimRight(p, ". ") != p || !filepath.IsLocal(p) || strings.ContainsAny(p, `<>:"/\|?*`) {
		return false
	}
	for _, c := range p {
		if c < 32 || c == 127 {
			return false
		}
	}
	stem := strings.ToUpper(strings.TrimRight(strings.SplitN(p, ".", 2)[0], " "))
	switch stem {
	case "CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$":
		return false
	}
	if strings.HasPrefix(stem, "COM") || strings.HasPrefix(stem, "LPT") {
		switch strings.TrimPrefix(strings.TrimPrefix(stem, "COM"), "LPT") {
		case "1", "2", "3", "4", "5", "6", "7", "8", "9", "¹", "²", "³":
			return false
		}
	}
	return true
}
