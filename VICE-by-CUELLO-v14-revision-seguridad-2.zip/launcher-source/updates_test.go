package main

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func TestObserve(t *testing.T) {
	a := strings.Repeat("a", 40)
	b := strings.Repeat("b", 40)
	p, n := observeVersion(portVersion{}, "old.exe", a)
	if n || p.Available {
		t.Fatal("unknown first check")
	}
	p, n = observeVersion(p, "old.exe", b)
	if !n || !p.Available {
		t.Fatal("new upstream")
	}
	p, n = observeVersion(p, "old.exe", b)
	if n || !p.Available {
		t.Fatal("repeat")
	}
	p, n = observeVersion(p, "new.exe", b)
	if n || p.Available {
		t.Fatal("relink")
	}
	p.InstalledSHA = a
	p, n = observeVersion(p, "new.exe", b)
	if !p.Available {
		t.Fatal("known commit")
	}
}
func TestLatest(t *testing.T) {
	a := strings.Repeat("a", 40)
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/repos/owner/repo/commits" {
			t.Error(r.URL.Path)
		}
		w.Write([]byte(`[{"sha":"` + a + `"}]`))
	}))
	defer s.Close()
	v, e := getLatest(s.Client(), s.URL, "owner/repo")
	if e != nil || v != a {
		t.Fatal(v, e)
	}
}
func TestPrimary(t *testing.T) {
	if primaryState(false, false, false, "XCL") != "Instalar XCL" || primaryState(true, false, false, "XCL") != "Vincular juego" || primaryState(true, true, false, "XCL") != "Jugar con XCL" {
		t.Fatal("state")
	}
}

func TestMetadataRedirect(t *testing.T) {
	for _, raw := range []string{"http://api.github.com/repos/a/b", "https://example.org/", "https://api.github.com.evil.test/", "https://user@api.github.com/", "https://api.github.com:444/"} {
		u, _ := url.Parse(raw)
		if checkMetadataRedirect(&http.Request{URL: u}, nil) == nil {
			t.Fatalf("accepted %s", raw)
		}
	}
	u, _ := url.Parse("https://api.github.com/repositories/123/commits")
	if checkMetadataRedirect(&http.Request{URL: u}, nil) != nil {
		t.Fatal("rejected GitHub")
	}
	if checkMetadataRedirect(&http.Request{URL: u}, make([]*http.Request, 5)) == nil {
		t.Fatal("too many redirects")
	}
}
