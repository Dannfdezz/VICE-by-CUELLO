package main

import (
	"bytes"
	"embed"
	"encoding/json"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

//go:embed banner.png
var banner []byte

//go:embed art/*.jpg
var artwork embed.FS
var u = syscall.NewLazyDLL("user32.dll")
var k = syscall.NewLazyDLL("kernel32.dll")
var gdi = syscall.NewLazyDLL("gdi32.dll")
var dlg = syscall.NewLazyDLL("comdlg32.dll")

func call(d *syscall.LazyDLL, n string, a ...uintptr) uintptr {
	r, _, _ := d.NewProc(n).Call(a...)
	return r
}
func s(v string) uintptr { return uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(v))) }

var win, info, logs, inst, play, combo, font uintptr
var root, libraryRoot string
var cfg struct{ Game, Engine string }
var extra struct {
	Engines        [5]string
	Selected, Mode int
}
var names = []string{"VIctory", "Hyphen", "ZTRX", "XCL", "Belobug AMD", "VItoriaBr"}
var repos = []string{"https://github.com/Marvisak/VIctory", "https://github.com/fxceless/victory-fork", "https://github.com/Zettrox/ztrx", "https://github.com/xcl-dev/xcl", "https://github.com/Belobug/VIctory-Belobug-AMD", "https://github.com/uiliannn/VItoriaBr"}
var keys = []string{"original", "hyphen", "ztrx", "xcl", "belobug", "vitoriabr"}

func engine(i int) string {
	if i == 0 {
		return cfg.Engine
	}
	return extra.Engines[i-1]
}
func installed(i int) bool { st, e := os.Stat(engine(i)); return e == nil && !st.IsDir() }
func saveExtra() {
	extra.Selected = selected
	extra.Mode = mode
	b, e := json.MarshalIndent(extra, "", "  ")
	if e == nil {
		e = os.WriteFile(filepath.Join(root, "motors-v5.json"), b, 0600)
	}
	if e != nil {
		msg(e.Error())
	}
}
func putEngine(i int, p string) {
	if i == 0 {
		cfg.Engine = p
		save()
	} else {
		extra.Engines[i-1] = p
		saveExtra()
	}
}

var running *exec.Cmd
var runMu sync.Mutex
var controls []uintptr
var busy bool
var playing bool
var appIcon, smallAppIcon uintptr
var done = make(chan string, 1)

type buildResult struct {
	i    int
	path string
	sha  string
}

var built = make(chan buildResult, 1)
var updates updateSettings
var checking bool
var checkedOK [6]bool
var updateNote = "GitHub: pendiente de comprobar"
var updateResults = make(chan updateResult, 1)

type downloadedSource struct {
	i        int
	dir, sha string
	err      error
}

var downloaded = make(chan downloadedSource, 1)
var pendingSources [6]downloadedSource

func gameLinked() bool { st, e := os.Stat(cfg.Game); return e == nil && !st.IsDir() }
func persistUpdates() {
	if e := writeUpdates(root, updates); e != nil {
		log("No se pudo guardar el estado de actualizaciones: " + e.Error())
	}
}
func startUpdateCheck(manual bool) {
	if checking || busy {
		return
	}
	if !manual && (updates.Disabled || time.Since(updates.LastCheck) < 15*time.Minute) {
		return
	}
	checking = true
	updateNote = "Consultando GitHub..."
	refresh()
	go func() {
		var r updateResult
		r.Manual = manual
		client := &http.Client{Timeout: 10 * time.Second, CheckRedirect: checkMetadataRedirect}
		var wg sync.WaitGroup
		for i, repo := range repositoryIDs {
			wg.Add(1)
			go func(i int, repo string) {
				defer wg.Done()
				sha, e := getLatest(client, "https://api.github.com", repo)
				if e != nil {
					r.Errors[i] = e.Error()
				} else {
					r.Versions[i] = sha
				}
			}(i, repo)
		}
		wg.Wait()
		updateResults <- r
		call(u, "PostMessageW", win, 0x8003, 0, 0)
	}()
}
func finishUpdateCheck(r updateResult) {
	checking = false
	updates.LastCheck = time.Now()
	var notice, report []string
	selectedUpdate := 0
	ok := 0
	for i, sha := range r.Versions {
		checkedOK[i] = sha != ""
		if sha == "" {
			report = append(report, names[i]+": "+r.Errors[i])
			continue
		}
		ok++
		if !installed(i) {
			updates.Ports[i] = portVersion{LatestSHA: sha}
			report = append(report, names[i]+": no instalado / "+shortSHA(sha))
			continue
		}
		p, n := observeVersion(updates.Ports[i], engine(i), sha)
		updates.Ports[i] = p
		state := "revision instalada desconocida"
		if p.InstalledSHA != "" {
			state = "base instalada " + shortSHA(p.InstalledSHA)
		}
		if p.Available {
			state = "cambios disponibles"
		}
		report = append(report, names[i]+": "+state+" / GitHub "+shortSHA(sha))
		if n {
			if len(notice) == 0 {
				selectedUpdate = i
			}
			notice = append(notice, names[i]+" — "+shortSHA(sha))
		}
	}
	persistUpdates()
	updateNote = fmt.Sprintf("GitHub: %d/6 comprobados", ok)
	refresh()
	if len(notice) > 0 && !playing {
		if confirm("Actualizaciones disponibles", "Hay cambios en los repositorios de:\n\n"+strings.Join(notice, "\n")+"\n\nTus versiones actuales siguen intactas. En motores importados solo se detectan cambios desde la primera consulta. Abrir el repositorio del primer motor y ver Instalaciones?", "Ver GitHub") {
			tab = 1
			selected = selectedUpdate
			saveExtra()
			openRepo(selectedUpdate, "")
			refresh()
		}
	} else if r.Manual {
		msg(strings.Join(report, "\n"))
	}
}
func openRepo(i int, suffix string) {
	call(syscall.NewLazyDLL("shell32.dll"), "ShellExecuteW", win, s("open"), s(repoURL(i)+suffix), 0, 0, 1)
}
func beginDownload(i int) {
	if busy {
		return
	}
	choice := showDialog("Actualizar / instalar motor", "Descargar la revisión más reciente de "+names[i]+" desde GitHub?\n\nSe conserva el motor actual hasta que la nueva versión compile y confirmes su activación. Revisa el código antes de compilar.", "Descargar", "GitHub", true)
	if choice == 2 {
		openRepo(i, "")
		return
	}
	if choice != 1 {
		return
	}
	busy = true
	status = "Descargando fuente de " + names[i] + "..."
	refresh()
	go func() {
		client := &http.Client{Timeout: 15 * time.Second, CheckRedirect: checkMetadataRedirect}
		sha, e := getLatest(client, "https://api.github.com", repositoryIDs[i])
		var dir string
		if e == nil {
			dir, e = downloadSource(repositoryIDs[i], sha, filepath.Join(libraryRoot, keys[i], "downloads"))
		}
		downloaded <- downloadedSource{i, dir, sha, e}
		call(u, "PostMessageW", win, 0x8004, 0, 0)
	}()
}
func finishDownload(d downloadedSource) {
	busy = false
	if d.err != nil {
		status = "Descarga fallida"
		refresh()
		msg(d.err.Error())
		return
	}
	pendingSources[d.i] = d
	writePending(root, pendingSources)
	status = "Fuente descargada y extraida. Revisa el codigo antes de compilar."
	refresh()
	exec.Command("explorer.exe", d.dir).Start()
	msg("Fuente de " + names[d.i] + " descargada: " + shortSHA(d.sha) + "\n\nRevisa el codigo y vuelve a Instalaciones > Compilar fuente descargada. No se ha ejecutado nada.")
}
func compileSource(i int, dir, sha string) {
	if busy {
		return
	}
	if _, e := exec.LookPath("cargo"); e != nil {
		msg("Falta Rust/Cargo. Instala Rust y Visual Studio Build Tools C++ desde sus sitios oficiales, reinicia el launcher y vuelve a probar.")
		return
	}
	if !confirm("Compilar código fuente", "Compilar ejecuta scripts de compilación del repositorio y sus dependencias. Confirma que has revisado y autorizado este código:\n\n"+dir+"\n\nSe creará una versión separada; no se sustituye el motor anterior sin confirmación.", "Compilar") {
		return
	}
	base := filepath.Join(libraryRoot, keys[i], "versions")
	if e := os.MkdirAll(base, 0755); e != nil {
		msg(e.Error())
		return
	}
	target, e := os.MkdirTemp(base, "build-")
	if e != nil {
		msg(e.Error())
		return
	}
	task("Compilando "+names[i], func() error {
		args := []string{"build", "--release", "-p", "victory", "--target-dir", target}
		binary := "victory.exe"
		if i == 3 {
			args = []string{"build", "--release", "--workspace", "--target-dir", target}
			binary = "xcl.exe"
		}
		if e := run(dir, "cargo", args...); e != nil {
			return e
		}
		p := filepath.Join(target, "release", binary)
		if _, e := os.Stat(p); e != nil {
			return e
		}
		built <- buildResult{i, p, sha}
		return nil
	})
}

type scanResult struct {
	paths [6][]string
	err   error
}

var scanned = make(chan scanResult, 1)

func chooseFolder() string {
	return chooseFolderTitle("Selecciona la carpeta donde tienes los motores extraidos")
}
func chooseFolderTitle(title string) string {
	shell := syscall.NewLazyDLL("shell32.dll")
	ole := syscall.NewLazyDLL("ole32.dll")
	var name [260]uint16
	var bi struct {
		Owner, Root, Display, Title uintptr
		Flags                       uint32
		Callback, Param             uintptr
		Image                       int32
	}
	bi.Owner = win
	bi.Display = uintptr(unsafe.Pointer(&name[0]))
	bi.Title = s(title)
	bi.Flags = 1
	pidl := call(shell, "SHBrowseForFolderW", uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return ""
	}
	defer call(ole, "CoTaskMemFree", pidl)
	var path [260]uint16
	if call(shell, "SHGetPathFromIDListW", pidl, uintptr(unsafe.Pointer(&path[0]))) == 0 {
		return ""
	}
	return syscall.UTF16ToString(path[:])
}
func importPorts() {
	if busy {
		return
	}
	dir := chooseFolder()
	if dir == "" {
		return
	}
	busy = true
	status = "Buscando motores existentes..."
	refresh()
	go func() {
		paths, err := discoverPorts(dir)
		scanned <- scanResult{paths, err}
		call(u, "PostMessageW", win, 0x8002, 0, 0)
	}()
}
func finishImport(r scanResult) {
	busy = false
	added := 0
	notes := []string{}
	if r.err != nil {
		notes = append(notes, r.err.Error())
	}
	for i, paths := range r.paths {
		if len(paths) == 0 {
			continue
		}
		if engine(i) != "" {
			notes = append(notes, names[i]+": vinculo previo conservado")
			continue
		}
		if len(paths) != 1 {
			notes = append(notes, fmt.Sprintf("%s: %d candidatos; usa Vincular motor EXE", names[i], len(paths)))
			continue
		}
		if confirm("Importar motor", "Vincular "+names[i]+" sin ejecutar ni copiar el archivo?\n\n"+paths[0]+"\n\nConfirma que es de origen autorizado.", "Vincular") {
			putEngine(i, paths[0])
			added++
		}
	}
	status = fmt.Sprintf("Importacion: %d motores vinculados", added)
	refresh()
	if len(notes) > 0 {
		msg(status + "\n\n" + strings.Join(notes, "\n"))
	} else {
		msg(status + ". Si falta alguno, vincula su EXE manualmente.")
	}
}

func msg(t string)            { showDialog("Información", t, "Aceptar", "", false) }
func set(h uintptr, t string) { call(u, "SetWindowTextW", h, s(t)) }
func save() {
	b, _ := json.Marshal(cfg)
	os.WriteFile(filepath.Join(root, "native.json"), b, 0600)
	refresh()
}

type ofn struct {
	Size                                    uint32
	Owner, Instance                         uintptr
	Filter, Custom                          uintptr
	MaxCustom, Index                        uint32
	File                                    uintptr
	MaxFile                                 uint32
	TitleFile                               uintptr
	MaxTitle                                uint32
	Initial, Title                          uintptr
	Flags                                   uint32
	Offset, Ext                             uint16
	Default, Data, Hook, Template, Reserved uintptr
	Reserved2, FlagsEx                      uint32
}

func choose(title string) string {
	return chooseFilter(title, []uint16{'E', 'X', 'E', 0, '*', '.', 'e', 'x', 'e', 0, 0})
}
func chooseManifest() string {
	return chooseFilter("Selecciona Cargo.toml", []uint16{'T', 'O', 'M', 'L', 0, '*', '.', 't', 'o', 'm', 'l', 0, 0})
}
func chooseFilter(title string, filter []uint16) string {
	b := make([]uint16, 32768)
	o := ofn{Size: uint32(unsafe.Sizeof(ofn{})), Owner: win, Filter: uintptr(unsafe.Pointer(&filter[0])), File: uintptr(unsafe.Pointer(&b[0])), MaxFile: uint32(len(b)), Title: s(title), Flags: 0x1000 | 0x800 | 0x80000}
	if call(dlg, "GetOpenFileNameW", uintptr(unsafe.Pointer(&o))) != 0 {
		return syscall.UTF16ToString(b)
	}
	return ""
}
func log(t string) {
	f, _ := os.OpenFile(filepath.Join(root, "launcher.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if f != nil {
		f.WriteString(t + "\n")
		f.Close()
	}
	status = t
	refresh()
}
func task(name string, fn func() error) {
	if busy {
		msg("Ya hay una tarea en curso.")
		return
	}
	busy = true
	log(name + "... Consulte launcher.log para detalles.")
	go func() {
		e := fn()
		t := name + ": completado"
		if e != nil {
			t = name + ": " + e.Error()
		}
		done <- t
		call(u, "PostMessageW", win, 0x8001, 0, 0)
	}()
}
func run(dir, exe string, args ...string) error { return runEnv(dir, exe, nil, false, args...) }
func runEnv(dir, exe string, env []string, gameWindow bool, args ...string) error {
	c := exec.Command(exe, args...)
	c.Dir = dir
	// GUI launch: redirect output to the existing log, without a separate console window.
	if gameWindow {
		c.SysProcAttr = &syscall.SysProcAttr{CreationFlags: 0x08000000}
	}
	if env != nil {
		c.Env = env
	}
	f, e := os.OpenFile(filepath.Join(root, "launcher.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	c.Stdout = f
	c.Stderr = f
	runMu.Lock()
	e = c.Start()
	if e == nil {
		running = c
	}
	runMu.Unlock()
	if e != nil {
		return e
	}
	e = c.Wait()
	runMu.Lock()
	running = nil
	runMu.Unlock()
	return e
}

func motorEnv(i int) []string {
	base := filepath.Join(root, "motors", keys[i])
	if managed := managedBuildDir(engine(i), keys[i]); managed != "" {
		base = managed
	} else if i == 0 {
		return nil
	}
	os.MkdirAll(filepath.Join(base, "cache"), 0755)
	os.MkdirAll(filepath.Join(base, "data"), 0755)
	env := []string{}
	for _, v := range os.Environ() {
		if !strings.HasPrefix(strings.ToUpper(v), "VICTORY_") && !strings.HasPrefix(strings.ToUpper(v), "XCL_DATA_ROOT=") {
			env = append(env, v)
		}
	}
	return append(env, "VICTORY_CACHE_DIR="+filepath.Join(base, "cache"), "VICTORY_DATA_DIR="+filepath.Join(base, "data"), "XCL_DATA_ROOT="+filepath.Join(base, "data"))
}
func build() error {
	return fmt.Errorf("Esta version no compila ni instala motores. Vincula un ejecutable existente y verificado.")
}
func valid() bool {
	if !confirm("Confirmar ejecución", "Ejecutar solo motores y archivos de juego de origen autorizado y previamente verificados. Continuar?", "Continuar") {
		return false
	}
	for _, p := range []string{cfg.Game, engine(selected)} {
		if st, e := os.Stat(p); e != nil || st.IsDir() {
			msg("Vincula el juego y el motor seleccionado en Instalaciones.")
			return false
		}
	}
	return true
}

var tab = 0
var mode = 0
var status = "Listo"
var selected = 0
var hits []hit
var regular, bold, big uintptr
var pixels []byte
var bw, bh int
var hardware = "Motor externo · archivos existentes"

type hit struct{ x, y, w, h, id int }

func refresh() {
	if win != 0 {
		call(u, "InvalidateRect", win, 0, 0)
	}
}
func color(r, g, b int) uintptr { return uintptr(r | g<<8 | b<<16) }

var bg = color(14, 15, 22)
var panel = color(25, 27, 38)
var purple = color(112, 65, 232)
var white = color(240, 240, 248)
var muted = color(166, 169, 188)

func rect(dc uintptr, x, y, w, h int, c uintptr, r int) {
	brush := call(gdi, "CreateSolidBrush", c)
	old := call(gdi, "SelectObject", dc, brush)
	pen := call(gdi, "GetStockObject", 8)
	op := call(gdi, "SelectObject", dc, pen)
	call(gdi, "RoundRect", dc, uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), uintptr(r), uintptr(r))
	call(gdi, "SelectObject", dc, old)
	call(gdi, "SelectObject", dc, op)
	call(gdi, "DeleteObject", brush)
}
func txt(dc uintptr, x, y int, t string, c, f uintptr) {
	call(gdi, "SelectObject", dc, f)
	call(gdi, "SetBkMode", dc, 1)
	call(gdi, "SetTextColor", dc, c)
	v := syscall.StringToUTF16(t)
	call(gdi, "TextOutW", dc, uintptr(x), uintptr(y), uintptr(unsafe.Pointer(&v[0])), uintptr(len(v)-1))
}
func button(dc uintptr, x, y, w, h, id int, t string, c uintptr) {
	rect(dc, x, y, w, h, c, 14)
	txt(dc, x+14, y+10, t, white, bold)
	hits = append(hits, hit{x, y, w, h, id})
}
func short(t string) string {
	r := []rune(t)
	if len(r) > 76 {
		return "…" + string(r[len(r)-75:])
	}
	return t
}

const baseW = 1200
const baseH = 760

var heading, heroFont, smallFont uintptr
var mouseID = -1
var anim = map[int]float64{}
var clientW, clientH = baseW, baseH
var heroArt, cardArt [6]artBitmap
var accents = []uintptr{color(146, 125, 255), color(186, 119, 250), color(141, 216, 130), color(108, 163, 243), color(255, 123, 160), color(255, 171, 109)}
var subtitles = []string{"Proyecto original", "Fork alternativo", "Variante NVIDIA RTX", "Capa alternativa Xbox Series", "Fork experimental AMD", "Variante experimental"}
var descriptions = [][]string{
	{"La base original del proyecto VIctory.", "Compatible con perfiles Series X y Series S."},
	{"Una variante de la base de VIctory.", "Compara su compatibilidad con el motor original."},
	{"Variante orientada a tarjetas NVIDIA RTX.", "Rendimiento y compatibilidad aún experimentales."},
	{"Capa de compatibilidad alternativa para Xbox Series.", "Necesita un ejecutable vinculado por separado."},
	{"Fork con cambios de compatibilidad gráfica.", "El renderizado y el rendimiento siguen en desarrollo."},
	{"Fork alternativo con cambios gráficos.", "El funcionamiento dentro del mundo no está confirmado."},
}

type artBitmap struct {
	pix  []byte
	w, h int
}

func decodeArt(b []byte) artBitmap {
	im, _, e := image.Decode(bytes.NewReader(b))
	if e != nil {
		return artBitmap{}
	}
	w, h := im.Bounds().Dx(), im.Bounds().Dy()
	p := make([]byte, w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			r, g, b, _ := im.At(x, y).RGBA()
			j := (y*w + x) * 4
			p[j] = byte(b >> 8)
			p[j+1] = byte(g >> 8)
			p[j+2] = byte(r >> 8)
		}
	}
	return artBitmap{p, w, h}
}
func drawArt(dc uintptr, a artBitmap, x, y, w, h int) {
	if len(a.pix) == 0 {
		return
	}
	var bi [40]byte
	*(*uint32)(unsafe.Pointer(&bi[0])) = 40
	*(*int32)(unsafe.Pointer(&bi[4])) = int32(a.w)
	*(*int32)(unsafe.Pointer(&bi[8])) = -int32(a.h)
	*(*uint16)(unsafe.Pointer(&bi[12])) = 1
	*(*uint16)(unsafe.Pointer(&bi[14])) = 32
	call(gdi, "SetStretchBltMode", dc, 4)
	call(gdi, "SetBrushOrgEx", dc, 0, 0, 0)
	call(gdi, "StretchDIBits", dc, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, uintptr(a.w), uintptr(a.h), uintptr(unsafe.Pointer(&a.pix[0])), uintptr(unsafe.Pointer(&bi[0])), 0, 0xcc0020)
}
func blend(a, b uintptr, t float64) uintptr {
	f := func(shift uint) int { return int(float64((a>>shift)&255)*(1-t) + float64((b>>shift)&255)*t) }
	return color(f(0), f(8), f(16))
}
func dynamicButton(dc uintptr, x, y, w, h, id int, t string, c uintptr) {
	a := anim[id]
	lift := int(a * 3)
	yy := y - lift
	rect(dc, x, yy+4, w, h, color(8, 9, 13), 14)
	rect(dc, x, yy, w, h, blend(c, color(240, 225, 255), a*.16), 14)
	txt(dc, x+15, yy+(h-19)/2, t, white, bold)
	hits = append(hits, hit{x, y - 4, w, h + 4, id})
}
func labelState(i int) string {
	if installed(i) {
		p := updates.Ports[i]
		if p.Path != engine(i) {
			return "Version desconocida"
		}
		if p.Available {
			if p.InstalledSHA != "" {
				return "Actualiz. disponible"
			}
			return "Cambios en GitHub"
		}
		if !checkedOK[i] {
			return "Sin verificar ahora"
		}
		if p.InstalledSHA != "" && p.InstalledSHA == p.LatestSHA {
			return "Actualizado"
		}
		return "Version desconocida"
	}
	return "No instalado"
}
func cards(dc uintptr, y int) {
	for i, n := range names {
		x := 30 + i*191
		a := anim[20+i]
		lift := int(a * 5)
		yy := y - lift
		border := color(37, 40, 53)
		if selected == i {
			border = accents[i]
		} else {
			border = blend(border, accents[i], a*.6)
		}
		rect(dc, x, yy+5, 185, 189, color(6, 7, 11), 16)
		rect(dc, x, yy, 185, 189, border, 16)
		rect(dc, x+2, yy+2, 181, 185, color(24, 26, 36), 14)
		drawArt(dc, cardArt[i], x+5, yy+5, 175, 109)
		txt(dc, x+12, yy+122, n, white, bold)
		stateColor := muted
		if installed(i) {
			stateColor = color(101, 220, 167)
			if updates.Ports[i].Available {
				stateColor = color(255, 192, 100)
			}
		}
		rect(dc, x+12, yy+150, 8, 8, stateColor, 8)
		txt(dc, x+26, yy+145, labelState(i), stateColor, smallFont)
		if selected == i {
			rect(dc, x+12, yy+174, 161, 3, accents[i], 3)
		}
		hits = append(hits, hit{x, y - 6, 185, 195, 20 + i})
	}
}
func paint(dc uintptr) {
	hits = nil
	rect(dc, 0, 0, baseW, baseH, color(12, 13, 19), 0)
	rect(dc, 0, 0, baseW, 73, color(20, 21, 29), 0)
	call(u, "DrawIconEx", dc, 29, 19, appIcon, 34, 34, 0, 0, 3)
	txt(dc, 75, 17, "VICE", white, heading)
	txt(dc, 136, 24, "by CUELLO", muted, regular)
	for i, n := range []string{"Biblioteca", "Instalaciones", "Ajustes"} {
		x := 300 + i*158
		c := color(20, 21, 29)
		if tab == i {
			c = color(43, 37, 64)
		}
		dynamicButton(dc, x, 16, 148, 41, 10+i, n, c)
		if tab == i {
			rect(dc, x+15, 56, 118, 3, accents[selected], 3)
		}
	}
	txt(dc, 1030, 21, "v13.0 / Windows", muted, smallFont)
	if tab == 0 {
		drawArt(dc, heroArt[selected], 30, 90, 1140, 342)
		txt(dc, 57, 110, "BIBLIOTECA   /   XBOX SERIES", color(216, 193, 239), smallFont)
		txt(dc, 54, 137, "Grand Theft Auto VI", white, heroFont)
		txt(dc, 57, 192, names[selected]+"  /  "+subtitles[selected], accents[selected], heading)
		for j, t := range descriptions[selected] {
			txt(dc, 58, 234+j*23, t, color(227, 224, 235), regular)
		}
		sc := muted
		if installed(selected) {
			sc = color(105, 224, 168)
		}
		rect(dc, 58, 293, 9, 9, sc, 9)
		txt(dc, 76, 286, labelState(selected)+"   ·   Experimental", sc, regular)
		playLabel := primaryState(installed(selected), gameLinked(), busy, names[selected])
		dynamicButton(dc, 55, 343, 260, 55, 7, playLabel, color(113, 64, 231))
		dynamicButton(dc, 328, 343, 164, 55, 8, "Preparar shaders", color(40, 39, 53))
		dynamicButton(dc, 504, 343, 145, 55, 9, "Detener", color(40, 39, 53))
		dynamicButton(dc, 665, 343, 245, 55, 42, "Buscar actualizaciones", color(55, 44, 82))
		if installed(selected) && updates.Ports[selected].Available {
			dynamicButton(dc, 924, 343, 215, 55, 43, "Actualizar motor", purple)
		}
		txt(dc, 30, 451, "Tus motores", white, heading)
		txt(dc, 874, 457, "6 versiones  /  Selecciona una portada", muted, smallFont)
		cards(dc, 493)
	} else if tab == 1 {
		txt(dc, 30, 92, "Instalaciones", white, heroFont)
		txt(dc, 32, 147, "Tus archivos permanecen donde están. Vincula o compila cada motor por separado.", muted, regular)
		rect(dc, 30, 180, 1140, 92, panel, 16)
		txt(dc, 48, 192, "ARCHIVO DEL JUEGO", muted, smallFont)
		v := cfg.Game
		if v == "" {
			v = "Sin vincular"
		}
		txt(dc, 48, 223, short(v), white, regular)
		dynamicButton(dc, 876, 202, 275, 47, 3, "Vincular juego existente", purple)
		cards(dc, 292)
		rect(dc, 30, 503, 1140, 175, panel, 16)
		txt(dc, 48, 519, names[selected], white, heading)
		v = engine(selected)
		if v == "" {
			v = "Sin vincular"
		}
		txt(dc, 49, 554, short(v), muted, regular)
		label := "Compilar fuente local"
		if pendingSources[selected].dir != "" {
			label = "Compilar fuente descargada"
		}
		dynamicButton(dc, 48, 603, 250, 46, 40, label, purple)
		dynamicButton(dc, 311, 603, 210, 46, 4, "Vincular motor EXE", color(39, 41, 53))
		dynamicButton(dc, 534, 603, 178, 46, 5, "Abrir GitHub", color(39, 41, 53))
		dlLabel := "Descargar fuente"
		if installed(selected) {
			dlLabel = "Reinstalar / actualizar"
			if updates.Ports[selected].Available {
				dlLabel = "Actualizar motor"
			}
		}
		dynamicButton(dc, 725, 603, 205, 46, 43, dlLabel, color(39, 41, 53))
		p := updates.Ports[selected]
		local := "desconocida"
		if p.Path == engine(selected) && p.InstalledSHA != "" {
			local = shortSHA(p.InstalledSHA)
		}
		remote := shortSHA(p.LatestSHA)
		if remote == "" {
			remote = "pendiente"
		}
		txt(dc, 49, 654, updateNote+"   |   Instalada: "+local+"   |   GitHub: "+remote+"   |   "+labelState(selected), muted, smallFont)
		dynamicButton(dc, 876, 125, 275, 42, 42, "Buscar actualizaciones", color(55, 44, 82))
		dynamicButton(dc, 941, 603, 210, 46, 41, "Detectar motores", color(55, 44, 82))
	} else {
		txt(dc, 30, 92, "Ajustes", white, heroFont)
		txt(dc, 32, 147, "Configuración del motor · No modifica servicios ni protecciones de Windows.", muted, regular)
		rect(dc, 30, 190, 1140, 205, panel, 16)
		txt(dc, 50, 210, "Perfil de consola", white, heading)
		txt(dc, 50, 250, "La compatibilidad depende de cada variante y del hardware.", muted, regular)
		dynamicButton(dc, 50, 300, 240, 52, 30, "Series X", []uintptr{purple, color(39, 41, 53)}[mode])
		dynamicButton(dc, 305, 300, 240, 52, 31, "Series S", []uintptr{color(39, 41, 53), purple}[mode])
		rect(dc, 30, 414, 1140, 204, panel, 16)
		txt(dc, 50, 436, "Datos y diagnóstico", white, heading)
		txt(dc, 50, 475, "Configuración y cachés existentes en AppData. Los motores conservan sus rutas.", muted, regular)
		txt(dc, 50, 501, "Nuevas instalaciones: "+short(libraryRoot), muted, smallFont)
		dynamicButton(dc, 50, 534, 250, 52, 6, "Abrir datos y registros", purple)
		autoLabel := "Avisos automaticos: SI"
		if updates.Disabled {
			autoLabel = "Avisos automaticos: NO"
		}
		dynamicButton(dc, 320, 534, 275, 52, 44, autoLabel, color(39, 41, 53))
		dynamicButton(dc, 615, 534, 255, 52, 42, "Buscar actualizaciones", color(55, 44, 82))
	}
	rect(dc, 0, 706, baseW, 54, color(19, 20, 27), 0)
	st := color(101, 220, 167)
	if busy {
		st = color(255, 192, 100)
	}
	rect(dc, 30, 727, 9, 9, st, 9)
	txt(dc, 48, 720, short(status), white, regular)
	txt(dc, 879, 720, "Proyecto experimental · Sin garantía de juego", muted, smallFont)
}
func hitAt(x, y int) int {
	for _, a := range hits {
		if x >= a.x && x < a.x+a.w && y >= a.y && y < a.y+a.h {
			return a.id
		}
	}
	return -1
}
func updateHover(id int) {
	if id != mouseID {
		mouseID = id
		call(u, "SetTimer", win, 1, 16, 0)
	}
}
func animate() {
	active := false
	for id, v := range anim {
		target := 0.0
		if id == mouseID {
			target = 1
		}
		v += (target - v) * .28
		if v < .015 && target == 0 {
			delete(anim, id)
		} else {
			anim[id] = v
		}
		if v-target > .015 || target-v > .015 {
			active = true
		}
	}
	if mouseID >= 0 {
		if _, ok := anim[mouseID]; !ok {
			anim[mouseID] = .28
			active = true
		}
	}
	refresh()
	if !active {
		call(u, "KillTimer", win, 1)
	}
}

func action(id int) {
	if busy && (id == 3 || id == 4 || id == 5 || id == 40 || id == 41 || id == 43 || id == 44 || id == 42 || id == 30 || id == 31 || (id >= 20 && id <= 25)) {
		msg("Deten la tarea antes de cambiar ajustes.")
		return
	}
	switch id {
	case 10, 11, 12:
		tab = id - 10
	case 20, 21, 22, 23, 24, 25:
		selected = id - 20
		saveExtra()
	case 30, 31:
		mode = id - 30
		saveExtra()
	case 3:
		if p := choose("Selecciona game_scarlett_master.exe"); p != "" {
			cfg.Game = p
			save()
		}
	case 4:
		if p := choose("Selecciona el EXE de " + names[selected]); p != "" {
			putEngine(selected, p)
		}
	case 5:
		if repos[selected] == "" {
			msg("Fuente incluida localmente.")
			break
		}
		call(syscall.NewLazyDLL("shell32.dll"), "ShellExecuteW", win, s("open"), s(repos[selected]), 0, 0, 1)
	case 41:
		importPorts()
	case 42:
		startUpdateCheck(true)
	case 43:
		beginDownload(selected)
	case 44:
		updates.Disabled = !updates.Disabled
		persistUpdates()
		if !updates.Disabled {
			startUpdateCheck(true)
		}
	case 40:
		i := selected
		if pendingSources[i].dir != "" {
			d := pendingSources[i]
			compileSource(i, d.dir, d.sha)
			break
		}
		self, e := os.Executable()
		if e != nil {
			msg(e.Error())
			break
		}
		dirs := []string{"VIctory-main", "victory-fork-main", "ztrx-main", "xcl-main", "VIctory-Belobug-AMD-main", "VItoriaBr-main"}
		dir := filepath.Join(filepath.Dir(self), "sources", dirs[i])
		if _, e := os.Stat(filepath.Join(dir, "Cargo.toml")); e != nil {
			p := chooseManifest()
			if p == "" {
				break
			}
			dir = filepath.Dir(p)
		}
		compileSource(i, dir, "")
	case 6:
		exec.Command("explorer.exe", root).Start()
	case 7:
		if busy {
			msg("Ya hay una tarea en curso.")
			break
		}
		if !installed(selected) {
			tab = 1
			beginDownload(selected)
			break
		}
		if !gameLinked() {
			action(3)
			break
		}
		if valid() {
			i := selected
			exe := engine(i)
			game := cfg.Game
			m := []string{"series-x", "series-s"}[mode]
			args := []string{"run", game, "--execute", "--console", m}
			if i == 3 {
				args = []string{"run", filepath.Dir(game)}
			}
			if i == 2 {
				args = []string{"run", game, "--execute"}
			}
			playing = true
			task("Ejecutando "+names[i], func() error { return runEnv(filepath.Dir(exe), exe, motorEnv(i), true, args...) })
			call(u, "ShowWindow", win, 0)
		}
	case 8:
		if busy {
			msg("Ya hay una tarea en curso.")
			break
		}
		if selected != 0 {
			msg("Consulta la preparacion de shaders del motor seleccionado en su repositorio. No se usa la cache original.")
			break
		}
		if valid() {
			task("Preparando shaders", func() error {
				d := filepath.Dir(cfg.Game)
				return runEnv(filepath.Dir(cfg.Engine), cfg.Engine, motorEnv(0), false, "translate", "--cache", "--pipelines", filepath.Join(d, "shaders.rpf"), cfg.Game, filepath.Join(d, "XboxBvhBuilder.dll"), filepath.Join(d, "amd_fidelityfx_upscaler_xbox.dll"))
			})
		}
	case 9:
		runMu.Lock()
		if running != nil && running.Process != nil {
			running.Process.Kill()
		}
		runMu.Unlock()
	}
	refresh()
}
func proc(h, m, w, l uintptr) uintptr {
	if currentDialog != nil {
		if m >= 0x8001 && m <= 0x8004 {
			deferredMessages = append(deferredMessages, uint32(m))
			return 0
		}
		if m == 0x113 && w == 77 {
			return 0
		}
	}
	switch m {
	case 0x8003:
		finishUpdateCheck(<-updateResults)
		return 0
	case 0x8004:
		finishDownload(<-downloaded)
		return 0
	case 0x8002:
		finishImport(<-scanned)
		return 0
	case 0x8001:
		log(<-done)
		select {
		case r := <-built:
			if confirm("Motor compilado", "Nueva compilación lista:\n"+r.path+"\n\nVincular esta versión ahora? La anterior y su caché se conservan. Puedes volver a vincularla manualmente.", "Activar versión") {
				old := engine(r.i)
				if old != "" {
					f, _ := os.OpenFile(filepath.Join(root, "engine-history-v10.txt"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
					if f != nil {
						fmt.Fprintln(f, names[r.i]+": "+old)
						f.Close()
					}
				}
				putEngine(r.i, r.path)
				updates.Ports[r.i] = portVersion{Path: r.path, InstalledSHA: r.sha, SeenSHA: r.sha, LatestSHA: r.sha}
				persistUpdates()
				pendingSources[r.i] = downloadedSource{}
				writePending(root, pendingSources)
			}
		default:
		}
		busy = false
		if playing {
			playing = false
			call(u, "ShowWindow", win, 5)
			call(u, "SetForegroundWindow", win)
		}
		refresh()
		return 0
	case 0x14:
		return 1
	case 0x5:
		clientW = int(l & 65535)
		clientH = int((l >> 16) & 65535)
		refresh()
		return 0
	case 0x113:
		if w == 77 {
			if !playing {
				startUpdateCheck(false)
			}
			return 0
		}
		animate()
		return 0
	case 0x200:
		if clientW > 0 && clientH > 0 {
			updateHover(hitAt(int(int16(l&65535))*baseW/clientW, int(int16((l>>16)&65535))*baseH/clientH))
		}
		var tr struct {
			Size, Flags uint32
			H           uintptr
			Hover       uint32
		}
		tr.Size = uint32(unsafe.Sizeof(tr))
		tr.Flags = 2
		tr.H = h
		call(u, "TrackMouseEvent", uintptr(unsafe.Pointer(&tr)))
		return 0
	case 0x2A3:
		updateHover(-1)
		return 0
	case 0xF:
		var ps [80]byte
		dc := call(u, "BeginPaint", h, uintptr(unsafe.Pointer(&ps[0])))
		var cr [4]int32
		call(u, "GetClientRect", h, uintptr(unsafe.Pointer(&cr[0])))
		clientW = int(cr[2])
		clientH = int(cr[3])
		if clientW > 0 && clientH > 0 {
			mem := call(gdi, "CreateCompatibleDC", dc)
			bmp := call(gdi, "CreateCompatibleBitmap", dc, uintptr(clientW), uintptr(clientH))
			if mem != 0 && bmp != 0 {
				old := call(gdi, "SelectObject", mem, bmp)
				// Draw at the actual window pixel dimensions, not into a small bitmap.
				call(gdi, "SetMapMode", mem, 8)
				call(gdi, "SetWindowExtEx", mem, baseW, baseH, 0)
				call(gdi, "SetViewportExtEx", mem, uintptr(clientW), uintptr(clientH), 0)
				paint(mem)
				call(gdi, "SetMapMode", mem, 1)
				call(gdi, "BitBlt", dc, 0, 0, uintptr(clientW), uintptr(clientH), mem, 0, 0, 0xcc0020)
				call(gdi, "SelectObject", mem, old)
			}
			if bmp != 0 {
				call(gdi, "DeleteObject", bmp)
			}
			if mem != 0 {
				call(gdi, "DeleteDC", mem)
			}
		}
		call(u, "EndPaint", h, uintptr(unsafe.Pointer(&ps[0])))
		return 0
	case 0x202:
		if clientW > 0 && clientH > 0 {
			id := hitAt(int(int16(l&65535))*baseW/clientW, int(int16((l>>16)&65535))*baseH/clientH)
			if id >= 0 {
				action(id)
			}
		}
		return 0
	case 2:
		call(u, "PostQuitMessage", 0)
		return 0
	}
	return call(u, "DefWindowProcW", h, m, w, l)
}

type wc struct {
	Size, Style                                       uint32
	Proc                                              uintptr
	ClsExtra, WndExtra                                int32
	Instance, Icon, Cursor, Brush, Menu, Class, Small uintptr
}

func makefont(size, weight int) uintptr {
	return call(gdi, "CreateFontW", uintptr(-size), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, s("Segoe UI"))
}
func main() {
	runtime.LockOSThread()
	call(u, "SetProcessDPIAware")
	root = filepath.Join(os.Getenv("LOCALAPPDATA"), "VICE-Launcher")
	os.MkdirAll(root, 0755)
	libraryRoot = filepath.Join(root, "motors")
	if self, err := os.Executable(); err == nil {
		if p, err := os.Stat(filepath.Join(filepath.Dir(self), "vice-installed.marker")); err == nil && !p.IsDir() {
			libraryRoot = filepath.Join(filepath.Dir(self), "ports")
		}
	}
	updates = readUpdates(root)
	readPending(root)
	b, _ := os.ReadFile(filepath.Join(root, "native.json"))
	json.Unmarshal(b, &cfg)
	b, e5 := os.ReadFile(filepath.Join(root, "motors-v5.json"))
	if e5 != nil {
		b, _ = os.ReadFile(filepath.Join(root, "motors-v4.json"))
	}
	json.Unmarshal(b, &extra)
	if extra.Selected >= 0 && extra.Selected < len(names) {
		selected = extra.Selected
	}
	if extra.Mode >= 0 && extra.Mode < 2 {
		mode = extra.Mode
	}
	im, _, e := image.Decode(bytes.NewReader(banner))
	if e == nil {
		bw, bh = im.Bounds().Dx(), im.Bounds().Dy()
		pixels = make([]byte, bw*bh*4)
		for y := 0; y < bh; y++ {
			for x := 0; x < bw; x++ {
				r, g, b, _ := im.At(x, y).RGBA()
				i := (y*bw + x) * 4
				pixels[i] = byte(b >> 8)
				pixels[i+1] = byte(g >> 8)
				pixels[i+2] = byte(r >> 8)
			}
		}
	}
	for i := range names {
		b, _ := artwork.ReadFile(fmt.Sprintf("art/hero%d.jpg", i))
		heroArt[i] = decodeArt(b)
		b, _ = artwork.ReadFile(fmt.Sprintf("art/card%d.jpg", i))
		cardArt[i] = decodeArt(b)
	}
	regular = makefont(16, 400)
	heading = makefont(24, 650)
	heroFont = makefont(48, 700)
	smallFont = makefont(14, 400)
	bold = makefont(16, 600)
	big = makefont(25, 700)
	instance := call(k, "GetModuleHandleW", 0)
	appIcon = call(u, "LoadImageW", instance, 101, 1, 32, 32, 0)
	smallAppIcon = call(u, "LoadImageW", instance, 101, 1, 16, 16, 0)
	class := s("ViceNativeWindow11")
	w := wc{Size: uint32(unsafe.Sizeof(wc{})), Proc: syscall.NewCallback(proc), Instance: instance, Icon: appIcon, Small: smallAppIcon, Cursor: call(u, "LoadCursorW", 0, 32512), Brush: call(gdi, "CreateSolidBrush", bg), Class: class}
	call(u, "RegisterClassExW", uintptr(unsafe.Pointer(&w)))
	var area [4]int32
	call(u, "SystemParametersInfoW", 48, 0, uintptr(unsafe.Pointer(&area[0])), 0)
	ww, hh := 1216, 800
	if area[2]-area[0] > 0 && int(area[2]-area[0])-40 < ww {
		ww = int(area[2]-area[0]) - 40
	}
	if area[3]-area[1] > 0 && int(area[3]-area[1])-40 < hh {
		hh = int(area[3]-area[1]) - 40
	}
	win = call(u, "CreateWindowExW", 0, class, s("VICE by CUELLO | Biblioteca"), 0x00CF0000, uintptr(int(area[0])+(int(area[2]-area[0])-ww)/2), uintptr(int(area[1])+(int(area[3]-area[1])-hh)/2), uintptr(ww), uintptr(hh), 0, 0, instance, 0)
	call(u, "SendMessageW", win, 0x80, 1, appIcon)
	call(u, "SendMessageW", win, 0x80, 0, smallAppIcon)
	call(u, "ShowWindow", win, 5)
	call(u, "SetTimer", win, 77, 900000, 0)
	updates.LastCheck = time.Time{}
	startUpdateCheck(false)
	var m [64]byte
	for int32(call(u, "GetMessageW", uintptr(unsafe.Pointer(&m[0])), 0, 0, 0)) > 0 {
		call(u, "TranslateMessage", uintptr(unsafe.Pointer(&m[0])))
		call(u, "DispatchMessageW", uintptr(unsafe.Pointer(&m[0])))
	}
}

// A pending download can be resumed after a restart. No code is executed on startup.
type savedPending struct{ Dir, SHA string }

func writePending(root string, list [6]downloadedSource) {
	var data [6]savedPending
	for i, v := range list {
		data[i] = savedPending{v.dir, v.sha}
	}
	b, e := json.MarshalIndent(data, "", "  ")
	if e == nil {
		if e = os.WriteFile(filepath.Join(root, "pending-v11.json"), b, 0600); e != nil {
			log("No se pudo guardar descarga pendiente: " + e.Error())
		}
	}
}
func readPending(root string) {
	var data [6]savedPending
	b, e := os.ReadFile(filepath.Join(root, "pending-v11.json"))
	if e != nil || json.Unmarshal(b, &data) != nil {
		return
	}
	for i, v := range data {
		if validSHA(v.SHA) && filepath.IsAbs(v.Dir) {
			if st, e := os.Stat(filepath.Join(v.Dir, "Cargo.toml")); e == nil && !st.IsDir() {
				pendingSources[i] = downloadedSource{i, v.Dir, v.SHA, nil}
			}
		}
	}
}
