package main

import (
	"runtime"
	"syscall"
	"unsafe"
)

type darkDialog struct {
	h                               uintptr
	title, body, primary, alternate string
	question                        bool
	result                          int
	ended                           bool
	focus, hover                    int
	w, height                       int
}

var currentDialog *darkDialog
var dialogClass *uint16
var dialogCallback = syscall.NewCallback(dialogProc)
var deferredMessages []uint32

// Draw wrapped text, and keep the real message readable instead of truncating it to a single line.
func dialogText(dc uintptr, x, y, w, h int, value string, ink, face uintptr, flags uintptr) {
	call(gdi, "SelectObject", dc, face)
	call(gdi, "SetBkMode", dc, 1)
	call(gdi, "SetTextColor", dc, ink)
	r := [4]int32{int32(x), int32(y), int32(x + w), int32(y + h)}
	v := syscall.StringToUTF16(value)
	call(u, "DrawTextW", dc, uintptr(unsafe.Pointer(&v[0])), uintptr(len(v)-1), uintptr(unsafe.Pointer(&r[0])), flags|0x800)
	runtime.KeepAlive(v)
}
func (d *darkDialog) buttons() []hit {
	y := d.height - 72
	b := []hit{{d.w - 206, y, 174, 44, 1}}
	if d.question {
		b = append(b, hit{d.w - 338, y, 120, 44, 0})
	}
	if d.alternate != "" {
		b = append(b, hit{d.w - 466, y, 116, 44, 2})
	}
	return append(b, hit{d.w - 56, 17, 34, 34, 0})
}
func (d *darkDialog) pick(x, y int) int {
	for _, b := range d.buttons() {
		if x >= b.x && x < b.x+b.w && y >= b.y && y < b.y+b.h {
			return b.id
		}
	}
	return -1
}
func (d *darkDialog) finish(choice int) {
	d.result = choice
	d.ended = true
	call(u, "DestroyWindow", d.h)
}
func dialogProc(h, m, w, l uintptr) uintptr {
	d := currentDialog
	if d == nil {
		return call(u, "DefWindowProcW", h, m, w, l)
	}
	switch m {
	case 0x14:
		return 1
	case 0xF:
		var ps [80]byte
		dc := call(u, "BeginPaint", h, uintptr(unsafe.Pointer(&ps[0])))
		rect(dc, 0, 0, d.w, d.height, color(19, 20, 28), 0)
		txt(dc, 30, 23, "VICE by CUELLO", muted, smallFont)
		rect(dc, 30, 68, 46, 46, color(42, 32, 64), 14)
		dialogText(dc, 30, 68, 46, 46, "↻", color(190, 160, 255), heading, 0x25)
		dialogText(dc, 91, 73, d.w-125, 40, d.title, white, heading, 0x24)
		rect(dc, 30, 131, d.w-60, 1, color(53, 53, 65), 0)
		dialogText(dc, 32, 151, d.w-64, d.height-239, d.body, color(218, 219, 232), regular, 0x10)
		rect(dc, 30, d.height-93, d.w-60, 1, color(53, 53, 65), 0)
		for _, b := range d.buttons() {
			if b.y == 17 {
				dialogText(dc, b.x, b.y, b.w, b.h, "×", muted, heading, 0x25)
				continue
			}
			c := color(38, 39, 51)
			label := "Cancelar"
			if b.id == 1 {
				c = color(112, 65, 232)
				label = d.primary
			}
			if b.id == 2 {
				label = d.alternate
			}
			if d.hover == b.id {
				c = blend(c, color(255, 255, 255), .12)
			}
			if d.focus == b.id {
				rect(dc, b.x-2, b.y-2, b.w+4, b.h+4, color(181, 154, 255), 12)
			}
			rect(dc, b.x, b.y, b.w, b.h, c, 12)
			dialogText(dc, b.x, b.y, b.w, b.h, label, white, bold, 0x25)
		}
		call(u, "EndPaint", h, uintptr(unsafe.Pointer(&ps[0])))
		return 0
	case 0x200:
		v := d.pick(int(int16(l&65535)), int(int16(l>>16)))
		if v != d.hover {
			d.hover = v
			call(u, "InvalidateRect", h, 0, 0)
		}
		return 0
	case 0x202:
		if id := d.pick(int(int16(l&65535)), int(int16(l>>16))); id >= 0 {
			d.finish(id)
		}
		return 0
	case 0x100:
		switch w {
		case 27:
			d.finish(0)
		case 13, 32:
			d.finish(d.focus)
		case 9:
			if !d.question {
				d.focus = 1
			} else if d.alternate != "" {
				d.focus = (d.focus + 1) % 3
			} else {
				d.focus = 1 - d.focus
			}
			call(u, "InvalidateRect", h, 0, 0)
		}
		return 0
	case 0x10:
		d.finish(0)
		return 0
	}
	return call(u, "DefWindowProcW", h, m, w, l)
}
func showDialog(title, body, primary, alternate string, question bool) int {
	if currentDialog != nil {
		return 0
	}
	if dialogClass == nil {
		dialogClass = syscall.StringToUTF16Ptr("ViceDarkDialog13")
		c := wc{Size: uint32(unsafe.Sizeof(wc{})), Proc: dialogCallback, Instance: call(k, "GetModuleHandleW", 0), Cursor: call(u, "LoadCursorW", 0, 32512), Class: uintptr(unsafe.Pointer(dialogClass))}
		call(u, "RegisterClassExW", uintptr(unsafe.Pointer(&c)))
	}
	d := &darkDialog{title: title, body: body, primary: primary, alternate: alternate, question: question, w: 680, height: 390, hover: -1, focus: 0}
	if !question {
		d.focus = 1
	}
	// Measure text at the actual font size, allowing long paths and reports.
	dc := call(u, "GetDC", win)
	call(gdi, "SelectObject", dc, regular)
	v := syscall.StringToUTF16(body)
	r := [4]int32{0, 0, int32(d.w - 64), 0}
	call(u, "DrawTextW", dc, uintptr(unsafe.Pointer(&v[0])), uintptr(len(v)-1), uintptr(unsafe.Pointer(&r[0])), 0x410|0x800)
	call(u, "ReleaseDC", win, dc)
	runtime.KeepAlive(v)
	if n := int(r[3]) + 248; n > d.height {
		d.height = n
	}
	var area, owner [4]int32
	call(u, "SystemParametersInfoW", 48, 0, uintptr(unsafe.Pointer(&area[0])), 0)
	call(u, "GetWindowRect", win, uintptr(unsafe.Pointer(&owner[0])))
	if d.height > int(area[3]-area[1])-24 { // preserve full text in native dialog if display is too small
		flags := uintptr(0)
		if question {
			flags = 0x124
		}
		if call(u, "MessageBoxW", win, s(body), s(title), flags) == 6 {
			return 1
		}
		return 0
	}
	x := int(owner[0]+owner[2])/2 - d.w/2
	y := int(owner[1]+owner[3])/2 - d.height/2
	if x < int(area[0]) {
		x = int(area[0])
	}
	if y < int(area[1]) {
		y = int(area[1])
	}
	if x+d.w > int(area[2]) {
		x = int(area[2]) - d.w
	}
	if y+d.height > int(area[3]) {
		y = int(area[3]) - d.height
	}
	currentDialog = d
	d.h = call(u, "CreateWindowExW", 0x00000001, uintptr(unsafe.Pointer(dialogClass)), s(title), 0x80800000, uintptr(x), uintptr(y), uintptr(d.w), uintptr(d.height), win, 0, call(k, "GetModuleHandleW", 0), 0)
	if d.h == 0 {
		currentDialog = nil
		flags := uintptr(0)
		if question {
			flags = 0x124
		}
		if call(u, "MessageBoxW", win, s(body), s(title), flags) == 6 {
			return 1
		}
		return 0
	}
	call(u, "EnableWindow", win, 0)
	call(u, "ShowWindow", d.h, 5)
	call(u, "SetForegroundWindow", d.h)
	call(u, "SetFocus", d.h)
	var message [64]byte
	for !d.ended {
		n := int32(call(u, "GetMessageW", uintptr(unsafe.Pointer(&message[0])), 0, 0, 0))
		if n <= 0 {
			if n == 0 {
				call(u, "PostQuitMessage", 0)
			}
			break
		}
		call(u, "TranslateMessage", uintptr(unsafe.Pointer(&message[0])))
		call(u, "DispatchMessageW", uintptr(unsafe.Pointer(&message[0])))
	}
	if !d.ended {
		call(u, "DestroyWindow", d.h)
	}
	currentDialog = nil
	call(u, "EnableWindow", win, 1)
	call(u, "SetForegroundWindow", win)
	call(u, "SetFocus", win)
	for _, m := range deferredMessages {
		call(u, "PostMessageW", win, uintptr(m), 0, 0)
	}
	deferredMessages = nil
	return d.result
}
func confirm(title, body, primary string) bool {
	return showDialog(title, body, primary, "", true) == 1
}
