package main

import (
	"archive/zip"
	"bytes"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"testing"
)

func TestArchiveNames(t *testing.T) {
	for _, n := range []string{"..", "NUL.txt", "COM1", "LPT².log", "foo:stream", "foo?", "x ", "x.", "a\\b", "a\x01b"} {
		if safeArchiveComponent(n) {
			t.Errorf("accepted %q", n)
		}
	}
	for _, n := range []string{"Cargo.toml", "victory-gpu", "src"} {
		if !safeArchiveComponent(n) {
			t.Errorf("rejected %q", n)
		}
	}
}
func TestSourceRedirect(t *testing.T) {
	for _, x := range []string{"http://codeload.github.com/a", "https://evil.example/a", "https://codeload.github.com:444/a", "https://x@codeload.github.com/a"} {
		u, _ := url.Parse(x)
		if checkSourceRedirect(&http.Request{URL: u}, nil) == nil {
			t.Errorf("accepted %s", x)
		}
	}
	u, _ := url.Parse("https://codeload.github.com/a")
	if checkSourceRedirect(&http.Request{URL: u}, nil) != nil {
		t.Fatal("official host rejected")
	}
	if knownRepository("unknown/other") || !knownRepository(repositoryIDs[0]) {
		t.Fatal("allowlist")
	}
}
func TestArchiveTraversal(t *testing.T) {
	for _, name := range []string{"repo/../outside", "repo/NUL.txt", "repo/a:stream"} {
		var b bytes.Buffer
		w := zip.NewWriter(&b)
		f, _ := w.Create(name)
		f.Write([]byte("x"))
		w.Close()
		r, e := zip.NewReader(bytes.NewReader(b.Bytes()), int64(b.Len()))
		if e != nil {
			continue
		}
		dir := t.TempDir()
		if _, e = extractSource(r, filepath.Join(dir, "out")); e == nil {
			t.Fatalf("accepted %s", name)
		}
		if _, e = os.Stat(filepath.Join(dir, "outside")); !os.IsNotExist(e) {
			t.Fatal("outside created")
		}
	}
}
