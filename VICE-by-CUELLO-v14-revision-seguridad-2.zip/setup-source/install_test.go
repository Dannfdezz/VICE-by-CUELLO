package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestInstall(t *testing.T) {
	d := filepath.Join(t.TempDir(), "VICE Launcher")
	b := []byte("MZ-test")
	p, e := installTo(d, b)
	if e != nil {
		t.Fatal(e)
	}
	got, e := os.ReadFile(p)
	if e != nil || !bytes.Equal(got, b) {
		t.Fatal("copy")
	}
	for _, key := range portNames {
		if _, e := os.Stat(filepath.Join(d, "ports", key)); e != nil {
			t.Fatal(e)
		}
	}
	if _, e := installTo(d, b); e != nil {
		t.Fatal(e)
	}
	if _, e := installTo(d, []byte("MZ-other")); e == nil {
		t.Fatal("overwrote existing")
	}
	got, _ = os.ReadFile(p)
	if !bytes.Equal(got, b) {
		t.Fatal("changed existing")
	}
}

func TestInstallRejectsLinks(t *testing.T) {
	d := t.TempDir()
	outside := filepath.Join(d, "outside.exe")
	b := []byte("MZ-test")
	if err := os.WriteFile(outside, b, 0600); err != nil {
		t.Fatal(err)
	}
	target := filepath.Join(d, launcherName)
	if err := os.Symlink(outside, target); err != nil {
		t.Skip(err)
	}
	if _, err := installTo(d, b); err == nil {
		t.Fatal("accepted executable symlink")
	}
	got, _ := os.ReadFile(outside)
	if !bytes.Equal(got, b) {
		t.Fatal("modified external file")
	}
	d2 := t.TempDir()
	if err := os.Symlink(d, filepath.Join(d2, "ports")); err != nil {
		t.Skip(err)
	}
	if _, err := installTo(d2, b); err == nil {
		t.Fatal("accepted ports symlink")
	}
}

func TestInstallRejectsAncestorLink(t *testing.T) {
	d := t.TempDir()
	outside := filepath.Join(d, "outside")
	if err := os.Mkdir(outside, 0700); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(d, "link")
	if err := os.Symlink(outside, link); err != nil {
		t.Skip(err)
	}
	if _, err := installTo(filepath.Join(link, "new", "app"), []byte("MZ-test")); err == nil {
		t.Fatal("accepted ancestor symlink")
	}
	if _, err := os.Stat(filepath.Join(outside, "new")); !os.IsNotExist(err) {
		t.Fatal("unexpected external directory")
	}
}
