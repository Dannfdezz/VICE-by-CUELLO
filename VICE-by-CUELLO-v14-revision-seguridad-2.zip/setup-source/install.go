package main

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
)

const launcherName = "VICE-by-CUELLO-v14.exe"

var portNames = []string{"original", "hyphen", "ztrx", "xcl", "belobug", "vitoriabr"}

// Explicit per-user installation. Existing files and versions are not replaced.
func installTo(dir string, payload []byte) (string, error) {
	if !filepath.IsAbs(dir) || filepath.Dir(dir) == dir {
		return "", fmt.Errorf("Elige una carpeta de instalacion, no la raiz de una unidad")
	}
	if len(payload) < 2 || !bytes.Equal(payload[:2], []byte("MZ")) {
		return "", fmt.Errorf("El archivo del launcher no es valido")
	}
	for _, p := range []string{dir, filepath.Join(dir, "sources"), filepath.Join(dir, "ports")} {
		if e := ensureInstallDir(p); e != nil {
			return "", e
		}
	}
	for _, key := range portNames {
		if e := ensureInstallDir(filepath.Join(dir, "ports", key)); e != nil {
			return "", e
		}
	}
	target := filepath.Join(dir, launcherName)
	info, e := os.Lstat(target)
	if e == nil {
		if !info.Mode().IsRegular() {
			return "", fmt.Errorf("El destino existente no es un archivo regular")
		}
		old, e := os.ReadFile(target)
		if e != nil {
			return "", e
		}
		if !bytes.Equal(old, payload) {
			return "", fmt.Errorf("Ya existe otro archivo con ese nombre. Elige otra carpeta; no se sobrescribira.")
		}
	} else if !os.IsNotExist(e) {
		return "", e
	} else {
		f, e := os.OpenFile(target, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if e != nil {
			return "", e
		}
		n, e := f.Write(payload)
		ce := f.Close()
		if e != nil || ce != nil || n != len(payload) {
			os.Remove(target)
			return "", fmt.Errorf("No se pudo copiar el launcher completo")
		}
	}
	marker := filepath.Join(dir, "vice-installed.marker")
	f, e := os.OpenFile(marker, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e == nil {
		_, e = f.WriteString("VICE by CUELLO 14\n")
		ce := f.Close()
		if e != nil {
			return "", e
		}
		if ce != nil {
			return "", ce
		}
	} else if !os.IsExist(e) {
		return "", e
	} else {
		info, err := os.Lstat(marker)
		if err != nil || !info.Mode().IsRegular() {
			return "", fmt.Errorf("Marcador de instalacion no valido")
		}
	}
	return target, nil
}

// Do not reuse a symbolic link as an installation directory.
func ensureInstallDir(p string) error {
	p = filepath.Clean(p)
	parent := filepath.Dir(p)
	if parent != p {
		if err := ensureInstallDir(parent); err != nil {
			return err
		}
	}
	st, err := os.Lstat(p)
	if err == nil {
		if !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
			return fmt.Errorf("Carpeta de instalacion no valida: %s", p)
		}
		return nil
	}
	if !os.IsNotExist(err) {
		return err
	}
	return os.Mkdir(p, 0755)
}
