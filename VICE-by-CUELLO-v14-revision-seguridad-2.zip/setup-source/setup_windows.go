package main

import (
	"bytes"
	_ "embed"
	"image"
	"image/color"
	_ "image/png"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

//go:embed payload.exe
var payload []byte

//go:embed brand.png
var brand []byte
var u = syscall.NewLazyDLL("user32.dll")
var k = syscall.NewLazyDLL("kernel32.dll")
var gdi = syscall.NewLazyDLL("gdi32.dll")
var shell = syscall.NewLazyDLL("shell32.dll")
var win, edit, action, browseBtn, instance, font, titleFont, smallFont, editBrush, bgBrush uintptr
var installedPath, status string
var dpi int = 96
var pixels []byte
var artW, artH int
var ink = rgb(244, 240, 250)
var muted = rgb(165, 159, 181)
var bg = rgb(13, 13, 17)
var field = rgb(24, 24, 30)
var purple = rgb(91, 54, 153)

func call(d *syscall.LazyDLL, n string, args ...uintptr) uintptr {
	r, _, _ := d.NewProc(n).Call(args...)
	return r
}
func s(v string) uintptr           { return uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(v))) }
func rgb(r, g, b int) uintptr      { return uintptr(r | g<<8 | b<<16) }
func sc(v int) int                 { return (v*dpi + 48) / 96 }
func arg(v int) uintptr            { return uintptr(v) }
func ptr(v unsafe.Pointer) uintptr { return uintptr(v) }

type rect struct{ L, T, R, B int32 }

func rr(x, y, w, h int) rect {
	return rect{int32(sc(x)), int32(sc(y)), int32(sc(x + w)), int32(sc(y + h))}
}
func solid(c uintptr) uintptr { return call(gdi, "CreateSolidBrush", c) }
func fill(dc uintptr, r rect, c uintptr) {
	b := solid(c)
	call(u, "FillRect", dc, ptr(unsafe.Pointer(&r)), b)
	call(gdi, "DeleteObject", b)
}
func rounded(dc uintptr, r rect, c uintptr, rad int) {
	b := solid(c)
	ob := call(gdi, "SelectObject", dc, b)
	op := call(gdi, "SelectObject", dc, call(gdi, "GetStockObject", 8))
	call(gdi, "RoundRect", dc, uintptr(r.L), uintptr(r.T), uintptr(r.R), uintptr(r.B), arg(sc(rad)), arg(sc(rad)))
	call(gdi, "SelectObject", dc, ob)
	call(gdi, "SelectObject", dc, op)
	call(gdi, "DeleteObject", b)
}
func text(dc uintptr, t string, r rect, f, c, flags uintptr) {
	old := call(gdi, "SelectObject", dc, f)
	call(gdi, "SetBkMode", dc, 1)
	call(gdi, "SetTextColor", dc, c)
	call(u, "DrawTextW", dc, s(t), ^uintptr(0), ptr(unsafe.Pointer(&r)), flags|0x800)
	call(gdi, "SelectObject", dc, old)
}
func set(h uintptr, t string) { call(u, "SetWindowTextW", h, s(t)) }
func alert(t string)          { call(u, "MessageBoxW", win, s(t), s("VICE by CUELLO"), 0x30) }
func read(h uintptr) string {
	var b [32768]uint16
	call(u, "GetWindowTextW", h, ptr(unsafe.Pointer(&b[0])), uintptr(len(b)))
	return syscall.UTF16ToString(b[:])
}
func child(class, t string, style uintptr, x, y, w, h, id int) uintptr {
	v := call(u, "CreateWindowExW", 0, s(class), s(t), 0x50000000|style, arg(sc(x)), arg(sc(y)), arg(sc(w)), arg(sc(h)), win, arg(id), instance, 0)
	call(u, "SendMessageW", v, 0x30, font, 1)
	return v
}
func browse() string {
	var display [260]uint16
	var bi struct {
		Owner, Root, Display, Title uintptr
		Flags                       uint32
		Callback, Param             uintptr
		Image                       int32
	}
	bi.Owner = win
	bi.Display = ptr(unsafe.Pointer(&display[0]))
	bi.Title = s("Selecciona la carpeta de instalación")
	bi.Flags = 0x41
	p := call(shell, "SHBrowseForFolderW", ptr(unsafe.Pointer(&bi)))
	if p == 0 {
		return ""
	}
	defer call(syscall.NewLazyDLL("ole32.dll"), "CoTaskMemFree", p)
	var b [260]uint16
	if call(shell, "SHGetPathFromIDListW", p, ptr(unsafe.Pointer(&b[0]))) == 0 {
		return ""
	}
	return syscall.UTF16ToString(b[:])
}
func prepareArt() {
	data := brand
	if p, e := os.Executable(); e == nil {
		if st, e := os.Stat(filepath.Join(filepath.Dir(p), "logo.png")); e == nil && st.Size() < 12*1024*1024 {
			if b, e := os.ReadFile(filepath.Join(filepath.Dir(p), "logo.png")); e == nil {
				if cfg, _, e := image.DecodeConfig(bytes.NewReader(b)); e == nil && cfg.Width <= 4096 && cfg.Height <= 4096 && cfg.Width > 0 && cfg.Height > 0 {
					data = b
				}
			}
		}
	}
	img, _, e := image.Decode(bytes.NewReader(data))
	if e != nil {
		img, _, e = image.Decode(bytes.NewReader(brand))
	}
	if e != nil {
		return
	}
	b := img.Bounds()
	artW, artH = b.Dx(), b.Dy()
	pixels = make([]byte, artW*artH*4)
	for y := 0; y < artH; y++ {
		for x := 0; x < artW; x++ {
			c := color.NRGBAModel.Convert(img.At(x+b.Min.X, y+b.Min.Y)).(color.NRGBA)
			a := int(c.A)
			i := (y*artW + x) * 4
			pixels[i] = byte((int(c.B)*a + 17*(255-a)) / 255)
			pixels[i+1] = byte((int(c.G)*a + 13*(255-a)) / 255)
			pixels[i+2] = byte((int(c.R)*a + 13*(255-a)) / 255)
		}
	}
}

type bitmapInfo struct {
	Size                   uint32
	W, H                   int32
	Planes, Bits           uint16
	Compression, ImageSize uint32
	XP, YP                 int32
	Used, Important        uint32
}

func drawArt(dc uintptr) {
	if len(pixels) == 0 {
		return
	}
	w, h := 82, 82
	if artW*h > artH*w {
		h = w * artH / artW
	} else {
		w = h * artW / artH
	}
	bi := bitmapInfo{Size: 40, W: int32(artW), H: -int32(artH), Planes: 1, Bits: 32}
	call(gdi, "SetStretchBltMode", dc, 4)
	call(gdi, "StretchDIBits", dc, arg(sc((500-w)/2)), arg(sc(30+(82-h)/2)), arg(sc(w)), arg(sc(h)), 0, 0, arg(artW), arg(artH), ptr(unsafe.Pointer(&pixels[0])), ptr(unsafe.Pointer(&bi)), 0, 0x00CC0020)
}
func paint(h uintptr) {
	var ps [80]byte
	dc := call(u, "BeginPaint", h, ptr(unsafe.Pointer(&ps[0])))
	if dc == 0 {
		return
	}
	defer call(u, "EndPaint", h, ptr(unsafe.Pointer(&ps[0])))
	fill(dc, rr(0, 0, 500, 270), bg)
	drawArt(dc)
	text(dc, status, rr(20, 211, 460, 20), smallFont, muted, 1|4|32)
	text(dc, "Proyecto no oficial · No incluye el juego", rr(20, 239, 460, 18), smallFont, muted, 1|4|32)
}

type drawitem struct {
	Type, ID, Item, Action, State uint32
	Hwnd, DC                      uintptr
	Rect                          rect
	Data                          uintptr
}

func drawButton(l uintptr) {
	d := (*drawitem)(unsafe.Pointer(l))
	r := d.Rect
	fill(d.DC, r, bg)
	c := field
	tc := ink
	if d.ID == 102 {
		c = purple
	}
	if d.State&1 != 0 {
		if d.ID == 102 {
			c = rgb(91, 48, 180)
		} else {
			c = rgb(50, 46, 65)
		}
	}
	rounded(d.DC, r, c, 14)
	text(d.DC, read(d.Hwnd), r, font, tc, 1|4|32)
	if d.State&16 != 0 {
		f := r
		f.L += 3
		f.T += 3
		f.R -= 3
		f.B -= 3
		call(u, "DrawFocusRect", d.DC, ptr(unsafe.Pointer(&f)))
	}
}
func proc(h, m, w, l uintptr) uintptr {
	switch m {
	case 0x14:
		return 1
	case 0x0f:
		paint(h)
		return 0
	case 0x2b:
		drawButton(l)
		return 1
	case 0x133:
		call(gdi, "SetTextColor", w, ink)
		call(gdi, "SetBkColor", w, field)
		return editBrush
	case 0x111:
		switch w & 0xffff {
		case 101:
			if p := browse(); p != "" {
				set(edit, p)
			}
		case 102:
			if installedPath != "" {
				c := exec.Command(installedPath)
				c.Dir = filepath.Dir(installedPath)
				if e := c.Start(); e != nil {
					alert(e.Error())
				} else {
					call(u, "DestroyWindow", win)
				}
				return 0
			}
			dir := strings.TrimSpace(read(edit))
			if dir == "" {
				alert("Selecciona una carpeta.")
				return 0
			}
			dir = filepath.Clean(dir)
			if call(u, "MessageBoxW", win, s("Instalar el launcher en:\n\n"+dir+"\n\nTus motores, cachés y configuraciones existentes no se moverán."), s("Confirmar instalación"), 0x24) != 6 {
				return 0
			}
			p, e := installTo(dir, payload)
			if e != nil {
				alert(e.Error())
				return 0
			}
			installedPath = p
			status = "Instalación completada · Listo para abrir"
			set(action, "Abrir launcher")
			call(u, "EnableWindow", edit, 0)
			call(u, "EnableWindow", browseBtn, 0)
			call(u, "InvalidateRect", win, 0, 0)
		}
		return 0
	case 2:
		call(u, "PostQuitMessage", 0)
		return 0
	}
	return call(u, "DefWindowProcW", h, m, w, l)
}

type wc struct {
	Size, Style                                       uint32
	Proc                                              uintptr
	ClsExtra, WndExtra                                int32
	Instance, Icon, Cursor, Brush, Menu, Class, Small uintptr
}

func makeFont(n, weight int) uintptr {
	return call(gdi, "CreateFontW", uintptr(-sc(n)), 0, 0, 0, arg(weight), 0, 0, 0, 1, 0, 0, 5, 0, s("Segoe UI"))
}
func main() {
	runtime.LockOSThread()
	call(u, "SetProcessDPIAware")
	dc := call(u, "GetDC", 0)
	if d := int(call(gdi, "GetDeviceCaps", dc, 88)); d >= 96 && d <= 384 {
		dpi = d
	}
	call(u, "ReleaseDC", 0, dc)
	ole := syscall.NewLazyDLL("ole32.dll")
	call(ole, "CoInitializeEx", 0, 2)
	defer call(ole, "CoUninitialize")
	instance = call(k, "GetModuleHandleW", 0)
	ic := call(u, "LoadImageW", instance, 101, 1, 32, 32, 0)
	cl := s("ViceInstaller11Design")
	bgBrush = solid(bg)
	editBrush = solid(field)
	font = makeFont(16, 500)
	titleFont = makeFont(27, 700)
	smallFont = makeFont(12, 500)
	prepareArt()
	status = ""
	c := wc{Size: uint32(unsafe.Sizeof(wc{})), Proc: syscall.NewCallback(proc), Instance: instance, Icon: ic, Small: ic, Cursor: call(u, "LoadCursorW", 0, 32512), Brush: bgBrush, Class: cl}
	call(u, "RegisterClassExW", ptr(unsafe.Pointer(&c)))
	style := uintptr(0x00CA0000)
	r := rr(0, 0, 500, 270)
	call(u, "AdjustWindowRectEx", ptr(unsafe.Pointer(&r)), style, 0, 0)
	ww, hh := int(r.R-r.L), int(r.B-r.T)
	var wa rect
	call(u, "SystemParametersInfoW", 48, 0, ptr(unsafe.Pointer(&wa)), 0)
	x, y := int(wa.L)+(int(wa.R-wa.L)-ww)/2, int(wa.T)+(int(wa.B-wa.T)-hh)/2
	win = call(u, "CreateWindowExW", 0, cl, s("VICE by CUELLO | Instalación"), style, arg(x), arg(y), arg(ww), arg(hh), 0, 0, instance, 0)
	if win == 0 {
		return
	}
	edit = child("EDIT", filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "VICE Launcher"), 0x10080, 57, 174, 302, 22, 105)
	browseBtn = child("BUTTON", "Cambiar", 0x1000B, 366, 168, 80, 32, 101)
	action = child("BUTTON", "Instalar", 0x1000B, 165, 118, 170, 39, 102)
	call(u, "SendMessageW", edit, 0x30, smallFont, 1)
	// Request dark native title bar on supported Windows versions.
	if p := syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute"); p.Find() == nil {
		dark := int32(1)
		p.Call(win, 20, ptr(unsafe.Pointer(&dark)), 4)
	}
	call(u, "ShowWindow", win, 5)
	call(u, "UpdateWindow", win)
	call(u, "SetFocus", action)
	var m [64]byte
	for int32(call(u, "GetMessageW", ptr(unsafe.Pointer(&m[0])), 0, 0, 0)) > 0 {
		if call(u, "IsDialogMessageW", win, ptr(unsafe.Pointer(&m[0]))) == 0 {
			call(u, "TranslateMessage", ptr(unsafe.Pointer(&m[0])))
			call(u, "DispatchMessageW", ptr(unsafe.Pointer(&m[0])))
		}
	}
}
