# VICE by CUELLO · v14.0 (revisión de seguridad, experimental)

Gestor no oficial de ports y capas de compatibilidad Xbox Series para Windows x64. No afiliado a Rockstar Games, Microsoft ni a los desarrolladores de los ports. No incluye juegos, ejecutables de ports ni datos de usuarios. Utiliza únicamente archivos obtenidos legítimamente.

## Instalación
1. Descarga `VICE-by-CUELLO-Setup.exe` de Releases tras revisar su procedencia y analizarlo con tu antivirus.
2. Elige una carpeta, pulsa Instalar y después Abrir launcher.
3. Vincula tus archivos de juego autorizados y selecciona un motor. Puedes importar un ejecutable existente o descargar su fuente desde GitHub y compilarla tras revisarla. Cargo/Rust y Visual Studio Build Tools C++ son requisitos de los ports Rust, no del launcher.

## Actualizar desde una versión anterior
Cierra el launcher y copia `VICE-by-CUELLO-v14.exe` a la carpeta de tu launcher anterior. No borres `sources`, `ports`, ni `%LOCALAPPDATA%\VICE-Launcher`. Se conservan los formatos de configuración y las rutas de los motores, así como las cachés anteriores. Las nuevas compilaciones pueden necesitar preparar sus propios shaders. No se garantiza la compatibilidad de los ports ni la migración de partidas.

## Actualizaciones de ports
Consulta GitHub al iniciar y cada 15 minutos cuando está inactivo, o manualmente. Los motores importados sin SHA conocido no se consideran automáticamente actualizados. Las revisiones nuevas se descargan y compilan con autorización y se activan solo tras confirmar; las anteriores se conservan como respaldo. Cada repositorio tiene sus propias licencias y requisitos.

## Compilar desde el código fuente
Con Go 1.23 o compatible, desde PowerShell en la raíz de este código:
```powershell
$env:GO111MODULE='off'
$env:GOOS='windows'
$env:GOARCH='amd64'
cd launcher-source
go build -ldflags='-H windowsgui -s -w' -o ..\VICE-by-CUELLO-v14.exe .
Copy-Item ..\VICE-by-CUELLO-v14.exe ..\setup-source\payload.exe
cd ..\setup-source
go build -ldflags='-H windowsgui -s -w' -o ..\VICE-by-CUELLO-Setup.exe .
```
El payload se genera localmente y no se incluye en el ZIP de código. El instalador no descarga ni ejecuta software de terceros automáticamente.

## Seguridad y distribución
Las pruebas unitarias de lógica se ejecutaron en Linux y se verificó la compilación cruzada para Windows. Este paquete entrega código fuente, no una versión binaria aprobada para distribución. No se ha ejecutado en Windows, firmado digitalmente ni analizado en VirusTotal. No se garantiza ausencia de avisos ni detecciones. Ante una alerta, conserva las protecciones y solicita revisión al proveedor. No publiques binarios antes de verificar su funcionamiento y seguridad. No publiques configuraciones privadas, juego, cachés ni registros.

El nuevo fondo de palmeras se ha creado como ilustración vectorial original; no incluye la imagen de Adobe Stock ni las anteriores portadas con personajes. El icono VI es la marca visual existente del proyecto; no implica autorización de terceros. Comprueba derechos de marcas y recursos antes de publicar. Revisa las licencias de los proyectos enlazados. No se concede ninguna licencia sobre código o recursos de terceros.

## Cambios v13
Diálogos oscuros personalizados para confirmaciones, avisos y errores del launcher. La descarga y compilación mantienen las autorizaciones originales. El progreso detallado sigue pendiente. Los selectores de archivos y el diálogo alternativo de emergencia continúan siendo nativos.

## Revisión v14
- Descarga de código restringida a los repositorios configurados y revisiones SHA válidas; redirecciones HTTPS limitadas a codeload.github.com.
- Extracción ZIP: rechazo adicional de nombres reservados de Windows, flujos alternativos y caracteres inválidos.
- Setup: rechaza enlaces simbólicos en destinos directos de instalación y marcadores no regulares; no sobrescribe ejecutables diferentes.
- Se mantienen los formatos de configuración y las rutas de motores de v13.
- Pruebas de regresión de descarga, nombres de archivo, extracción e instalación añadidas.

Límites: revisión parcial, no auditoría integral. No verifica la seguridad del código de terceros ni sus scripts Cargo. No cubre todas las carreras de acceso a rutas, enlaces de directorios ancestros, ni la autenticidad de editores de terceros. No se ha probado en Windows ni en VirusTotal. Para publicar, revisar los repositorios y dependencias, compilar en un entorno de confianza, firmar y solicitar revisión de detecciones a sus proveedores.

## Revisión adicional de seguridad (v14, revisión 2)
- Las consultas de metadatos a GitHub rechazan redirecciones a otros dominios, conexiones HTTP, credenciales en la URL y puertos explícitos; se mantiene la posibilidad de seguir redirecciones válidas en api.github.com.
- El instalador comprueba también los directorios ancestros del destino antes de crear carpetas, para evitar atravesar enlaces simbólicos preexistentes. Puede rechazar rutas redirigidas legítimas; esta comprobación no es una defensa completa frente a carreras de acceso o a todos los tipos de puntos de reanálisis de Windows.
- Las pruebas de lógica existentes y las nuevas pruebas de regresión pasan en Linux con Go 1.23.2. No se han generado ni analizado ejecutables de esta revisión; la validación en Windows sigue pendiente.
- No se cambia el formato de configuración ni la lógica de caché, ni se modifica ningún servicio o protección del sistema. No se afirma que las detecciones anteriores sean falsos positivos.
